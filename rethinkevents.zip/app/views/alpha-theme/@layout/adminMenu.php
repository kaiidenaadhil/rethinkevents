<?php return array (
  'eventCategories' => 
  array (
    'label' => 'Event Categories',
    'icon' => 'uil-sitemap',
  ),
  'events' => 
  array (
    'label' => 'Events',
    'icon' => 'uil-calender',
  ),
  'services' => 
  array (
    'label' => 'Services',
    'icon' => 'uil-wrench',
  ),
  'media' => 
  array (
    'label' => 'Media',
    'icon' => 'uil-file',
  ),
  'product' => 
  array (
    'label' => 'Product',
    'icon' => 'uil-file',
  ),
  'projects' => 
  array (
    'label' => 'Projects',
    'icon' => 'uil-file',
  ),
  'clients' => 
  array (
    'label' => 'Clients',
    'icon' => 'uil-file',
  ),
  'teams' => 
  array (
    'label' => 'Teams',
    'icon' => 'uil-file',
  ),
  'service_categories' => 
  array (
    'label' => 'Service_categories',
    'icon' => 'uil-file',
  ),
  'testimonials' => 
  array (
    'label' => 'Testimonials',
    'icon' => 'uil-file',
  ),
  'leads' => 
  array (
    'label' => 'Leads',
    'icon' => 'uil-file',
  ),
  'event_gallery' => 
  array (
    'label' => 'Event_gallery',
    'icon' => 'uil-file',
  ),
  'settings' => 
  array (
    'label' => 'Settings',
    'icon' => 'uil-file',
  ),
  'meta_seo' => 
  array (
    'label' => 'Meta_seo',
    'icon' => 'uil-file',
  ),
  'galleries' => 
  array (
    'label' => 'Galleries',
    'icon' => 'uil-file',
  ),
  'campaign' => 
  array (
    'label' => 'Campaign',
    'icon' => 'uil-file',
  ),
  'categories' => 
  array (
    'label' => 'Categories',
    'icon' => 'uil-file',
  ),
);