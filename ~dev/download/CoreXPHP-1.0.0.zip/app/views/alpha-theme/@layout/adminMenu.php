<?php return array (
  'eventCategories' => 
  array (
    'label' => 'Event Categories',
    'icon' => 'uil-sitemap',
  ),
  'events' => 
  array (
    'label' => 'Events',
    'icon' => 'uil-calender',
  ),
  'services' => 
  array (
    'label' => 'Services',
    'icon' => 'uil-wrench',
  ),
  'clients' => 
  array (
    'label' => 'Clients',
    'icon' => 'uil-users-alt',
  ),
  'testimonials' => 
  array (
    'label' => 'Testimonials',
    'icon' => 'uil-comment-verify',
  ),
  'inquiries' => 
  array (
    'label' => 'Inquiries',
    'icon' => 'uil-envelope-check',
  ),
  'teamMembers' => 
  array (
    'label' => 'Team Members',
    'icon' => 'uil-user-check',
  ),
  'blogPosts' => 
  array (
    'label' => 'Blog Posts',
    'icon' => 'uil-notebooks',
  ),
  'faqs' => 
  array (
    'label' => 'FAQs',
    'icon' => 'uil-question-circle',
  ),
  'portfolio' => 
  array (
    'label' => 'Portfolio',
    'icon' => 'uil-presentation-play',
  ),
  'product' => 
  array (
    'label' => 'Product',
    'icon' => 'uil-file',
  ),
  'categories' => 
  array (
    'label' => 'Categories',
    'icon' => 'uil-file',
  ),
);