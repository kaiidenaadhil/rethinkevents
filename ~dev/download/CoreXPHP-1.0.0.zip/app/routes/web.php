<?php
$app->router->get('', [HomeController::class, 'index']);
//$app->router->get('', [HomeController::class, 'index'],[AuthMiddleware::class]);
$app->router->post('', [HomeController::class, 'index']); 
$app->router->get('/contact-us', [ContactController::class, 'index']);
$app->router->post('/contact-us', [ContactController::class, 'contact']);

$app->router->get('/jwt', [JWTController::class, 'one']);


$app->router->get('/contract', [ContractController::class, 'contractForm']);
$app->router->post('/contract', [ContractController::class, 'contractForm']);

$app->router->get('/test', function () {
    echo "Route handler executed.";
}, [TestMiddleware::class]);



$app->router->resource('admin/eventCategories', 'eventCategories',EventCategoriesController::class);

$app->router->resource('admin/events', 'events',EventsController::class);

$app->router->resource('admin/services', 'services',ServicesController::class);

$app->router->resource('admin/portfolio', 'portfolio',PortfolioController::class);

$app->router->resource('admin/clients', 'clients',ClientsController::class);

$app->router->resource('admin/testimonials', 'testimonials',TestimonialsController::class);

$app->router->resource('admin/inquiries', 'inquiries',InquiriesController::class);

$app->router->resource('admin/blogPosts', 'blogPosts',BlogPostsController::class);

$app->router->resource('admin/faqs', 'faqs',FaqsController::class);

$app->router->resource('admin/product', 'product',ProductController::class);

$app->router->resource('admin/post', 'post',PostController::class);

$app->router->resource('admin/categories', 'categories',CategoriesController::class);
