<?php
class categoriesModel extends Model
{

	public function record($data = [])
	{
		$this->insert("categories", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("categories", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
		$columns = array (
  0 => 'categoryId',
  1 => 'categoryName',
  2 => 'categoryURI',
  3 => 'categoryCreatedAt',
  4 => 'categoryUpdatedAt',
  5 => 'categoryIdentify',
);
		return $this->paginate("categories", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
		$columns = array (
  0 => 'categoryId',
  1 => 'categoryName',
  2 => 'categoryURI',
  3 => 'categoryCreatedAt',
  4 => 'categoryUpdatedAt',
  5 => 'categoryIdentify',
);
		return $this->search("categories", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'categoryId',
  1 => 'categoryName',
  2 => 'categoryURI',
  3 => 'categoryCreatedAt',
  4 => 'categoryUpdatedAt',
  5 => 'categoryIdentify',
);
		return $this->select("categories", $columns, ["categoryIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("categories", $data, ["categoryIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("categories", ["categoryIdentify" => $id]);
	}
}
