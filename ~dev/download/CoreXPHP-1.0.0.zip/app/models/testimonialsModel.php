<?php
class testimonialsModel extends Model
{

	public function record($data = [])
	{
		$this->insert("testimonials", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("testimonials", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
           		$columns = array (
  0 => 'testimonialId',
  1 => 'clientId',
  2 => 'name',
  3 => 'message',
  4 => 'photo',
  5 => 'designation',
  6 => 'testimonialCreatedAt',
  7 => 'testimonialUpdatedAt',
  8 => 'testimonialIdentify',
);
		return $this->paginate("testimonials", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
	$columns = array (
  0 => 'testimonialId',
  1 => 'clientId',
  2 => 'name',
  3 => 'message',
  4 => 'photo',
  5 => 'designation',
  6 => 'testimonialCreatedAt',
  7 => 'testimonialUpdatedAt',
  8 => 'testimonialIdentify',
);
		return $this->search("testimonials", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'testimonialId',
  1 => 'clientId',
  2 => 'name',
  3 => 'message',
  4 => 'photo',
  5 => 'designation',
  6 => 'testimonialCreatedAt',
  7 => 'testimonialUpdatedAt',
  8 => 'testimonialIdentify',
);
		return $this->select("testimonials", $columns, ["testimonialIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("testimonials", $data, ["testimonialIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("testimonials", ["testimonialIdentify" => $id]);
	}
}
