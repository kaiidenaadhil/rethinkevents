<?php
class eventCategoriesModel extends Model
{

	public function record($data = [])
	{
		$this->insert("eventCategories", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("eventCategories", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
           		$columns = array (
  0 => 'categoryId',
  1 => 'name',
  2 => 'description',
  3 => 'status',
  4 => 'eventCategoryCreatedAt',
  5 => 'eventCategoryUpdatedAt',
  6 => 'eventCategoryIdentify',
);
		return $this->paginate("eventCategories", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
	$columns = array (
  0 => 'categoryId',
  1 => 'name',
  2 => 'description',
  3 => 'status',
  4 => 'eventCategoryCreatedAt',
  5 => 'eventCategoryUpdatedAt',
  6 => 'eventCategoryIdentify',
);
		return $this->search("eventCategories", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'categoryId',
  1 => 'name',
  2 => 'description',
  3 => 'status',
  4 => 'eventCategoryCreatedAt',
  5 => 'eventCategoryUpdatedAt',
  6 => 'eventCategoryIdentify',
);
		return $this->select("eventCategories", $columns, ["eventCategoryIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("eventCategories", $data, ["eventCategoryIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("eventCategories", ["eventCategoryIdentify" => $id]);
	}
}
