<?php
class portfolioModel extends Model
{

	public function record($data = [])
	{
		$this->insert("portfolio", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("portfolio", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
           		$columns = array (
  0 => 'portfolioId',
  1 => 'eventId',
  2 => 'galleryImage',
  3 => 'caption',
  4 => 'portfolioCreatedAt',
  5 => 'portfolioUpdatedAt',
  6 => 'portfolioIdentify',
);
		return $this->paginate("portfolio", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
	$columns = array (
  0 => 'portfolioId',
  1 => 'eventId',
  2 => 'galleryImage',
  3 => 'caption',
  4 => 'portfolioCreatedAt',
  5 => 'portfolioUpdatedAt',
  6 => 'portfolioIdentify',
);
		return $this->search("portfolio", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'portfolioId',
  1 => 'eventId',
  2 => 'galleryImage',
  3 => 'caption',
  4 => 'portfolioCreatedAt',
  5 => 'portfolioUpdatedAt',
  6 => 'portfolioIdentify',
);
		return $this->select("portfolio", $columns, ["portfolioIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("portfolio", $data, ["portfolioIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("portfolio", ["portfolioIdentify" => $id]);
	}
}
