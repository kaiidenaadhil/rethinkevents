<?php
class inquiriesModel extends Model
{

	public function record($data = [])
	{
		$this->insert("inquiries", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("inquiries", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
           		$columns = array (
  0 => 'inquiryId',
  1 => 'name',
  2 => 'email',
  3 => 'phone',
  4 => 'eventType',
  5 => 'message',
  6 => 'inquiryCreatedAt',
  7 => 'inquiryUpdatedAt',
  8 => 'inquiryIdentify',
);
		return $this->paginate("inquiries", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
	$columns = array (
  0 => 'inquiryId',
  1 => 'name',
  2 => 'email',
  3 => 'phone',
  4 => 'eventType',
  5 => 'message',
  6 => 'inquiryCreatedAt',
  7 => 'inquiryUpdatedAt',
  8 => 'inquiryIdentify',
);
		return $this->search("inquiries", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'inquiryId',
  1 => 'name',
  2 => 'email',
  3 => 'phone',
  4 => 'eventType',
  5 => 'message',
  6 => 'inquiryCreatedAt',
  7 => 'inquiryUpdatedAt',
  8 => 'inquiryIdentify',
);
		return $this->select("inquiries", $columns, ["inquiryIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("inquiries", $data, ["inquiryIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("inquiries", ["inquiryIdentify" => $id]);
	}
}
