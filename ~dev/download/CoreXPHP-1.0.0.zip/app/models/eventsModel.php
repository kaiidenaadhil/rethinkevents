<?php
class eventsModel extends Model
{

	public function record($data = [])
	{
		$this->insert("events", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("events", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
           		$columns = array (
  0 => 'eventId',
  1 => 'title',
  2 => 'categoryId',
  3 => 'location',
  4 => 'eventDate',
  5 => 'eventTime',
  6 => 'coverImage',
  7 => 'summary',
  8 => 'status',
  9 => 'eventCreatedAt',
  10 => 'eventUpdatedAt',
  11 => 'eventIdentify',
);
		return $this->paginate("events", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
	$columns = array (
  0 => 'eventId',
  1 => 'title',
  2 => 'categoryId',
  3 => 'location',
  4 => 'eventDate',
  5 => 'eventTime',
  6 => 'coverImage',
  7 => 'summary',
  8 => 'status',
  9 => 'eventCreatedAt',
  10 => 'eventUpdatedAt',
  11 => 'eventIdentify',
);
		return $this->search("events", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'eventId',
  1 => 'title',
  2 => 'categoryId',
  3 => 'location',
  4 => 'eventDate',
  5 => 'eventTime',
  6 => 'coverImage',
  7 => 'summary',
  8 => 'status',
  9 => 'eventCreatedAt',
  10 => 'eventUpdatedAt',
  11 => 'eventIdentify',
);
		return $this->select("events", $columns, ["eventIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("events", $data, ["eventIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("events", ["eventIdentify" => $id]);
	}
}
