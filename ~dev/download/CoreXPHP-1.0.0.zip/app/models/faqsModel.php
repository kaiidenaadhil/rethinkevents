<?php
class faqsModel extends Model
{

	public function record($data = [])
	{
		$this->insert("faqs", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("faqs", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
           		$columns = array (
  0 => 'faqId',
  1 => 'question',
  2 => 'answer',
  3 => 'faqCreatedAt',
  4 => 'faqUpdatedAt',
  5 => 'faqIdentify',
);
		return $this->paginate("faqs", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
	$columns = array (
  0 => 'faqId',
  1 => 'question',
  2 => 'answer',
  3 => 'faqCreatedAt',
  4 => 'faqUpdatedAt',
  5 => 'faqIdentify',
);
		return $this->search("faqs", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'faqId',
  1 => 'question',
  2 => 'answer',
  3 => 'faqCreatedAt',
  4 => 'faqUpdatedAt',
  5 => 'faqIdentify',
);
		return $this->select("faqs", $columns, ["faqIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("faqs", $data, ["faqIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("faqs", ["faqIdentify" => $id]);
	}
}
