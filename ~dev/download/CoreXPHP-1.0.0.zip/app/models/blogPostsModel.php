<?php
class blogPostsModel extends Model
{

	public function record($data = [])
	{
		$this->insert("blogPosts", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("blogPosts", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
           		$columns = array (
  0 => 'postId',
  1 => 'title',
  2 => 'slug',
  3 => 'content',
  4 => 'coverImage',
  5 => 'status',
  6 => 'blogPostCreatedAt',
  7 => 'blogPostUpdatedAt',
  8 => 'blogPostIdentify',
);
		return $this->paginate("blogPosts", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
	$columns = array (
  0 => 'postId',
  1 => 'title',
  2 => 'slug',
  3 => 'content',
  4 => 'coverImage',
  5 => 'status',
  6 => 'blogPostCreatedAt',
  7 => 'blogPostUpdatedAt',
  8 => 'blogPostIdentify',
);
		return $this->search("blogPosts", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'postId',
  1 => 'title',
  2 => 'slug',
  3 => 'content',
  4 => 'coverImage',
  5 => 'status',
  6 => 'blogPostCreatedAt',
  7 => 'blogPostUpdatedAt',
  8 => 'blogPostIdentify',
);
		return $this->select("blogPosts", $columns, ["blogPostIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("blogPosts", $data, ["blogPostIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("blogPosts", ["blogPostIdentify" => $id]);
	}
}
