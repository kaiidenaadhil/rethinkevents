<?php
class postModel extends Model
{

	public function record($data = [])
	{
		$this->insert("post", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("post", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
           		$columns = array (
  0 => 'postId',
  1 => 'postTitle',
  2 => 'postDesc',
  3 => 'postImg',
  4 => 'postType',
  5 => 'postboolean',
  6 => 'postFloat',
  7 => 'postCreatedAt',
  8 => 'postUpdatedAt',
  9 => 'postIdentify',
);
		return $this->paginate("post", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
	$columns = array (
  0 => 'postId',
  1 => 'postTitle',
  2 => 'postDesc',
  3 => 'postImg',
  4 => 'postType',
  5 => 'postboolean',
  6 => 'postFloat',
  7 => 'postCreatedAt',
  8 => 'postUpdatedAt',
  9 => 'postIdentify',
);
		return $this->search("post", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'postId',
  1 => 'postTitle',
  2 => 'postDesc',
  3 => 'postImg',
  4 => 'postType',
  5 => 'postboolean',
  6 => 'postFloat',
  7 => 'postCreatedAt',
  8 => 'postUpdatedAt',
  9 => 'postIdentify',
);
		return $this->select("post", $columns, ["postIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("post", $data, ["postIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("post", ["postIdentify" => $id]);
	}
}
