<?php
class servicesModel extends Model
{

	public function record($data = [])
	{
		$this->insert("services", $data);
	}

	public function countAll($search, $searchColumns)
	{
		return $this->searchCount("services", $search, $searchColumns);
	}

	public function displayAll($offset = null, $limit = null)
	{
           		$columns = array (
  0 => 'serviceId',
  1 => 'title',
  2 => 'category',
  3 => 'description',
  4 => 'icon',
  5 => 'status',
  6 => 'serviceCreatedAt',
  7 => 'serviceUpdatedAt',
  8 => 'serviceIdentify',
);
		return $this->paginate("services", $columns, [], $offset, $limit);
	}

	public function displayAllSearch($search, $searchColumns, $offset = null, $limit = null)
	{
	$columns = array (
  0 => 'serviceId',
  1 => 'title',
  2 => 'category',
  3 => 'description',
  4 => 'icon',
  5 => 'status',
  6 => 'serviceCreatedAt',
  7 => 'serviceUpdatedAt',
  8 => 'serviceIdentify',
);
		return $this->search("services", $columns, [], $search, $searchColumns, $offset, $limit);
	}

	public function displaySingle($id)
	{
		$columns = array (
  0 => 'serviceId',
  1 => 'title',
  2 => 'category',
  3 => 'description',
  4 => 'icon',
  5 => 'status',
  6 => 'serviceCreatedAt',
  7 => 'serviceUpdatedAt',
  8 => 'serviceIdentify',
);
		return $this->select("services", $columns, ["serviceIdentify" => $id]);
	}

	public function modify($data, $id)
	{
		return $this->updateWhere("services", $data, ["serviceIdentify" => $id]);
	}

	public function erase($id)
	{
		return $this->deleteWhere("services", ["serviceIdentify" => $id]);
	}
}
