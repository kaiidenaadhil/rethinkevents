<?php
use QueryBuilder as DB;

class HomeModel extends Model {
    
    public function getAllProducts() {
        // Define your filters for the count query
        $filters = [
            ['price', '>=', 50],            // Filter products with price >= 50
            ['stock_quantity', '<=', 100]   // Filter products with stock <= 100
        ];
        
        // Count the matching products based on filters
        try {
            $totalCount = DB::table('products')
                ->filter($filters)  // Apply filters
                ->get();           // Get the count of matching products

            // Return the count (total matching products)
            return $totalCount;

        } catch (Exception $e) {
            // Handle error if count query fails
            error_log('Error fetching product count: ' . $e->getMessage());
            return 0; // In case of error, return 0
        }
    }
}
