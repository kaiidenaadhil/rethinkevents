<?php
use QueryBuilder as DB;
class HomeModel extends Model {
    public function getAllProducts() {
        // Use DB::table() to query the 'products' table
       /*
        return DB::table('products')->get();

        return DB::table('products')->where('category_id', '=', 1)->get();

       return DB::table('products')->insert([
        'category_id' => 3,
        'name' => 'Sample Product',
        'description' => 'This is a sample product description.',
        'price' => 199.99,
        'stock_quantity' => 50,
        'image_url' => 'https://example.com/images/sample-product.jpg',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s'),
         ]);

        return DB::table('products')
        ->where('id', '=', 38)
        ->update([
            'name' => 'New Product Name',
            'price' => 150.00,
            'stock_quantity' => 20
        ]);
        return DB::table('products')
        ->where('id', '=', 38)
        ->delete();


        return DB::table('products')->truncate();

        return DB::table('products')
          ->whereBetween('price', [200, 600])
          ->get();


                  return DB::table('products')
          ->whereNotBetween('price', [200, 600])
          ->get();
        return DB::table('products')
        ->count();
                return DB::table('products')
        ->where('price', '=', '200')
        ->count();
        return DB::table('products')->sum('price');
          return DB::table('products')->avg('price');
           return DB::table('products')->min('price');
                  return DB::table('products')->max('price');
         return DB::table('products')
        ->where('category_id', '=', '1')
        ->sum('price');

        return DB::table('products')
        ->where('category_id', '=', '1')
        ->max('price');
        $sql = DB::table('products')
        ->where('category_id', '=', '1')
        ->toSql(); // Get the SQL query string.

                return DB::table('products')
        ->where('category_id', '=', 1)
        ->logQuery() // Logs the query to a file
        ->get();
                return DB::table('products')
        ->filter([
            ['price', '>=', 200],
            ['stock_quantity', '<', 100],
            ['category_id', 'IN', [1, 2]],
            ['created_at', 'BETWEEN', ['2024-01-01', '2024-12-31']],
            'status' => 'active'
        ])
        ->get();
        */
        $filters = [
          ['price', '>=', 50],
          ['stock_quantity', '<=', 100]
      ];
      
      $totalCount = DB::table('products')
          ->filter($filters)
          ->orderBy('price', 'DESC')
          ->count();
      
      echo "Total matching products: " . $totalCount;
        
    }
}
