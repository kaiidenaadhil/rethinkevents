<?php
class eventCategoriesController extends Controller
{
    public function eventCategoriesIndex()
    {
        $search               = isset($_GET['search']) ? $_GET['search'] : '';
        $eventCategoriesModel = $this->model('eventCategoriesModel');
        $searchColumns        = [
            0 => 'categoryId',
            1 => 'name',
            2 => 'description',
            3 => 'status',
            4 => 'eventCategoryCreatedAt',
            5 => 'eventCategoryUpdatedAt',
            6 => 'eventCategoryIdentify',
        ];
        $totalRecords              = $eventCategoriesModel->countAll($search, $searchColumns);
        $page                      = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        $pagination                = new Paginator($totalRecords, $page, 10);
        $data                      = $eventCategoriesModel->displayAllSearch($search, $searchColumns, $pagination->getOffset(), $pagination->getLimit());
        $params['eventCategories'] = $data;
        if ($totalRecords > $pagination->getLimit()) {
            $params['pagination'] = $pagination->render();
        } else {
            $params['pagination'] = '';
        }
        $this->adminView('eventCategories/eventCategoriesAll', $params);
    }

    public function eventCategoriesDisplay(Request $request, $eventCategoriesIdentify)
    {
        $eventCategoriesModel      = $this->model('eventCategoriesModel');
        $params['eventCategories'] = $eventCategoriesModel->displaySingle($eventCategoriesIdentify);
        $this->adminView('eventCategories/eventCategoriesSingle', $params);
    }

    public function eventCategoriesDestroy(Request $request, $eventCategoriesIdentify)
    {
        $eventCategoriesModel = $this->model('eventCategoriesModel');
        $eventCategoriesModel->erase($eventCategoriesIdentify);
        // success delete and redirect
        header("Location:  " . ROOT . "/admin/eventCategories/");
        $_SESSION['success_message'] = "Delete successful!";
        exit;
    }

    public function eventCategoriesbuild()
    {
        $this->adminView('eventCategories/eventCategoriesNew');
    }

    public function eventCategoriesRecord(Request $request)
    {
        $eventCategoriesModel          = $this->model('eventCategoriesModel');
        $data                          = $request->getBody();
        $data['eventCategoryCreatedAt']  = date('Y-m-d H:i:s');
        $data['eventCategoryUpdatedAt']  = date('Y-m-d H:i:s');
        $data['eventCategoryIdentify'] = generateUniqueId(16);
        $rules                         = [
            'name'                   => 'required|max:100',
            'description'            => '',
            'status'                 => 'required',
            'eventCategoryCreatedAt' => '',
            'eventCategoryUpdatedAt' => '',
            'eventCategoryIdentify'  => 'required|max:50',
        ];
        $validator = new Validator();
        $validator->validate($rules);
        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $eventCategoriesModel->record($data);
            // success adding and redirect
            header("Location:  " . ROOT . "/admin/eventCategories/");
            $_SESSION['success_message'] = "Added successful!";
            exit;
        }
    }

    public function eventCategoriesModify(Request $request, $eventCategoriesIdentify)
    {
        $eventCategoriesModel            = $this->model('eventCategoriesModel');
        $params['eventCategoryIdentify'] = $eventCategoriesIdentify;
        $params['eventCategories']       = $eventCategoriesModel->displaySingle($eventCategoriesIdentify);
        $this->adminView('eventCategories/eventCategoriesEdit', $params);
    }

    public function eventCategoriesEdit(Request $request, $eventCategoriesIdentify)
    {
        $eventCategoriesModel = $this->model('eventCategoriesModel');
        $data                 = $request->getBody();
        $rules                = [
            'name'                   => 'required|max:100',
            'description'            => '',
            'status'                 => 'required',
            'eventCategoryCreatedAt' => '',
            'eventCategoryUpdatedAt' => '',
            'eventCategoryIdentify'  => 'required|max:50',
        ];
        $validator = new Validator();

        if ($validator->fails($rules)) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $eventCategoriesModel->modify($data, $eventCategoriesIdentify);
            // success updated and redirect
            header("Location:  " . ROOT . "/admin/eventCategories/");
            $_SESSION['success_message'] = "Update successful!";
            exit;
        }
    }
}
