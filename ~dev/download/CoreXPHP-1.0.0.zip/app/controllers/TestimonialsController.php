<?php
class testimonialsController extends Controller
{
    public function testimonialsIndex()
    {
        $search            = isset($_GET['search']) ? $_GET['search'] : '';
        $testimonialsModel = $this->model('testimonialsModel');
        $searchColumns     = [
            0 => 'testimonialId',
            1 => 'clientId',
            2 => 'name',
            3 => 'message',
            4 => 'photo',
            5 => 'designation',
            6 => 'testimonialCreatedAt',
            7 => 'testimonialUpdatedAt',
            8 => 'testimonialIdentify',
        ];
        $totalRecords           = $testimonialsModel->countAll($search, $searchColumns);
        $page                   = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        $pagination             = new Paginator($totalRecords, $page, 10);
        $data                   = $testimonialsModel->displayAllSearch($search, $searchColumns, $pagination->getOffset(), $pagination->getLimit());
        $params['testimonials'] = $data;
        if ($totalRecords > $pagination->getLimit()) {
            $params['pagination'] = $pagination->render();
        } else {
            $params['pagination'] = '';
        }
        $this->adminView('testimonials/testimonialsAll', $params);
    }

    public function testimonialsDisplay(Request $request, $testimonialsIdentify)
    {
        $testimonialsModel      = $this->model('testimonialsModel');
        $params['testimonials'] = $testimonialsModel->displaySingle($testimonialsIdentify);
        $this->adminView('testimonials/testimonialsSingle', $params);
    }

    public function testimonialsDestroy(Request $request, $testimonialsIdentify)
    {
        $testimonialsModel = $this->model('testimonialsModel');
        $testimonialsModel->erase($testimonialsIdentify);
        // success delete and redirect
        header("Location:  " . ROOT . "/admin/testimonials/");
        $_SESSION['success_message'] = "Delete successful!";
        exit;
    }

    public function testimonialsbuild()
    {
        $this->adminView('testimonials/testimonialsNew');
    }

    public function testimonialsRecord(Request $request)
    {
        $testimonialsModel           = $this->model('testimonialsModel');
        $data                        = $request->getBody();
        $data['testimonialCreatedAt']  = date('Y-m-d H:i:s');
        $data['testimonialUpdatedAt']  = date('Y-m-d H:i:s');
        $data['testimonialIdentify'] = generateUniqueId(16);
        $rules                       = [
            'clientId'             => 'required',
            'name'                 => 'required|max:100',
            'message'              => '',
            'photo'                => 'required|max:255',
            'designation'          => 'required|max:100',
            'testimonialCreatedAt' => '',
            'testimonialUpdatedAt' => '',
            'testimonialIdentify'  => 'required|max:50',
        ];
        $validator = new Validator();
        $validator->validate($rules);
        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $testimonialsModel->record($data);
            // success adding and redirect
            header("Location:  " . ROOT . "/admin/testimonials/");
            $_SESSION['success_message'] = "Added successful!";
            exit;
        }
    }

    public function testimonialsModify(Request $request, $testimonialsIdentify)
    {
        $testimonialsModel             = $this->model('testimonialsModel');
        $params['testimonialIdentify'] = $testimonialsIdentify;
        $params['testimonials']        = $testimonialsModel->displaySingle($testimonialsIdentify);
        $this->adminView('testimonials/testimonialsEdit', $params);
    }

    public function testimonialsEdit(Request $request, $testimonialsIdentify)
    {
        $testimonialsModel = $this->model('testimonialsModel');
        $data              = $request->getBody();
        $rules             = [
            'clientId'             => 'required',
            'name'                 => 'required|max:100',
            'message'              => '',
            'photo'                => 'required|max:255',
            'designation'          => 'required|max:100',
            'testimonialCreatedAt' => '',
            'testimonialUpdatedAt' => '',
            'testimonialIdentify'  => 'required|max:50',
        ];
        $validator = new Validator();

        if ($validator->fails($rules)) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $testimonialsModel->modify($data, $testimonialsIdentify);
            // success updated and redirect
            header("Location:  " . ROOT . "/admin/testimonials/");
            $_SESSION['success_message'] = "Update successful!";
            exit;
        }
    }
}
