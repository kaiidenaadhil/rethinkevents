<?php
class postController extends Controller
{
    public function postIndex()
    {
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        $postModel = $this->model('postModel');
        	$searchColumns = array (
  0 => 'postId',
  1 => 'postTitle',
  2 => 'postDesc',
  3 => 'postImg',
  4 => 'postType',
  5 => 'postboolean',
  6 => 'postFloat',
  7 => 'postCreatedAt',
  8 => 'postUpdatedAt',
  9 => 'postIdentify',
);
        $totalRecords = $postModel->countAll($search, $searchColumns);
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $pagination = new Paginator($totalRecords, $page, 10);
        $data = $postModel->displayAllSearch($search, $searchColumns, $pagination->getOffset(), $pagination->getLimit());
        $params['post'] = $data;
        if ($totalRecords > $pagination->getLimit()) {
            $params['pagination'] =  $pagination->render();
        } else {
            $params['pagination'] = '';
        }
        $this->adminView('post/postAll', $params);
    }

    public function postDisplay(Request $request, $postIdentify)
    {
        $postModel = $this->model('postModel');
        $params['post'] =  $postModel->displaySingle($postIdentify);
        $this->adminView('post/postSingle', $params);
    }

    public function postDestroy(Request $request, $postIdentify)
    {
        $postModel = $this->model('postModel');
        $postModel->erase($postIdentify);
            // success delete and redirect
header("Location:  " . ROOT . "/admin/post/");
            $_SESSION['success_message'] = "Delete successful!";
            exit;
    }

    public function postbuild()
    {
        $this->adminView('post/postNew');
    }

    public function postRecord(Request $request)
    {
        $postModel = $this->model('postModel');
        $data = $request->getBody();
        $data['postCreatedAt'] = date('Y-m-d H:i:s');
        $data['postUpdatedAt'] = date('Y-m-d H:i:s');
        $data['postIdentify'] = generateUniqueId(16);
        	$rules = array (
  'postTitle' => 'required|max:250',
  'postDesc' => 'required|max:250',
  'postImg' => 'required|max:250',
  'postType' => '',
  'postboolean' => '',
  'postFloat' => 'max:8,2',
  'postCreatedAt' => '',
  'postUpdatedAt' => '',
  'postIdentify' => 'required|max:50',
);
        $validator = new Validator();
        $validator->validate($rules);
        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $postModel->record($data);
            // success adding and redirect
header("Location:  " . ROOT . "/admin/post/");
            $_SESSION['success_message'] = "Added successful!";
            exit;
        }
    }

    public function postModify(Request $request,$postIdentify)
    {
        $postModel = $this->model('postModel');
        $params['postIdentify'] = $postIdentify;
        $params['post'] =  $postModel->displaySingle($postIdentify);
        $this->adminView('post/postEdit', $params);
    }

    public function postEdit(Request $request, $postIdentify)
    {
        $postModel = $this->model('postModel');
        $data = $request->getBody();
        	$rules = array (
  'postTitle' => 'required|max:250',
  'postDesc' => 'required|max:250',
  'postImg' => 'required|max:250',
  'postType' => '',
  'postboolean' => '',
  'postFloat' => 'max:8,2',
  'postCreatedAt' => '',
  'postUpdatedAt' => '',
  'postIdentify' => 'required|max:50',
);
        $validator = new Validator();

        if ($validator->fails($rules)) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $postModel->modify($data, $postIdentify);
            // success updated and redirect
header("Location:  " . ROOT . "/admin/post/");
            $_SESSION['success_message'] = "Update successful!";
            exit;
        }
    }
}
