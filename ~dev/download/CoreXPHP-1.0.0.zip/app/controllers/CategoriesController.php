<?php
class categoriesController extends Controller
{
    public function categoriesIndex()
    {
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        $categoriesModel = $this->model('categoriesModel');
        	$searchColumns = array (
  0 => 'categoryId',
  1 => 'categoryName',
  2 => 'categoryURI',
  3 => 'categoryCreatedAt',
  4 => 'categoryUpdatedAt',
  5 => 'categoryIdentify',
);
        $totalRecords = $categoriesModel->countAll($search, $searchColumns);
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $pagination = new Paginator($totalRecords, $page, 10);
        $data = $categoriesModel->displayAllSearch($search, $searchColumns, $pagination->getOffset(), $pagination->getLimit());
        $params['categories'] = $data;
        if ($totalRecords > $pagination->getLimit()) {
            $params['pagination'] =  $pagination->render();
        } else {
            $params['pagination'] = '';
        }
        $this->adminView('categories/categoriesAll', $params);
    }

    public function categoriesDisplay(Request $request, $categoriesIdentify)
    {
        $categoriesModel = $this->model('categoriesModel');
        $params['categories'] =  $categoriesModel->displaySingle($categoriesIdentify);
        $this->adminView('categories/categoriesSingle', $params);
    }

    public function categoriesDestroy(Request $request, $categoriesIdentify)
    {
        $categoriesModel = $this->model('categoriesModel');
        $categoriesModel->erase($categoriesIdentify);
            // success delete and redirect
header("Location:  " . ROOT . "/admin/categories/");
            $_SESSION['success_message'] = "Delete successful!";
            exit;
    }

    public function categoriesbuild()
    {
        $this->adminView('categories/categoriesNew');
    }

    public function categoriesRecord(Request $request)
    {
        $categoriesModel = $this->model('categoriesModel');
        $data = $request->getBody();
        $data['categoryCreatedAt'] = date('Y-m-d H:i:s');
        $data['categoryUpdatedAt'] = date('Y-m-d H:i:s');
        $data['categoryIdentify'] = generateUniqueId(16);
        	$rules = array (
  'categoryName' => 'required|max:255',
  'categoryURI' => 'required|max:255',
  'categoryCreatedAt' => '',
  'categoryUpdatedAt' => '',
  'categoryIdentify' => 'required|max:50',
);
        $validator = new Validator();
        $validator->validate($rules);
        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $categoriesModel->record($data);
            // success adding and redirect
header("Location:  " . ROOT . "/admin/categories/");
            $_SESSION['success_message'] = "Added successful!";
            exit;
        }
    }

    public function categoriesModify(Request $request,$categoriesIdentify)
    {
        $categoriesModel = $this->model('categoriesModel');
        $params['categoryIdentify'] = $categoriesIdentify;
        $params['categories'] =  $categoriesModel->displaySingle($categoriesIdentify);
        $this->adminView('categories/categoriesEdit', $params);
    }

    public function categoriesEdit(Request $request, $categoriesIdentify)
    {
        $categoriesModel = $this->model('categoriesModel');
        $data = $request->getBody();
        	$rules = array (
  'categoryName' => 'required|max:255',
  'categoryURI' => 'required|max:255',
  'categoryCreatedAt' => '',
  'categoryUpdatedAt' => '',
  'categoryIdentify' => 'required|max:50',
);
        $validator = new Validator();

        if ($validator->fails($rules)) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $categoriesModel->modify($data, $categoriesIdentify);
            // success updated and redirect
header("Location:  " . ROOT . "/admin/categories/");
            $_SESSION['success_message'] = "Update successful!";
            exit;
        }
    }
}
