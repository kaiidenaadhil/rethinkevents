<?php
class servicesController extends Controller
{
    public function servicesIndex()
    {
        $search        = isset($_GET['search']) ? $_GET['search'] : '';
        $servicesModel = $this->model('servicesModel');
        $searchColumns = [
            0 => 'serviceId',
            1 => 'title',
            2 => 'category',
            3 => 'description',
            4 => 'icon',
            5 => 'status',
            6 => 'serviceCreatedAt',
            7 => 'serviceUpdatedAt',
            8 => 'serviceIdentify',
        ];
        $totalRecords       = $servicesModel->countAll($search, $searchColumns);
        $page               = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        $pagination         = new Paginator($totalRecords, $page, 10);
        $data               = $servicesModel->displayAllSearch($search, $searchColumns, $pagination->getOffset(), $pagination->getLimit());
        $params['services'] = $data;
        if ($totalRecords > $pagination->getLimit()) {
            $params['pagination'] = $pagination->render();
        } else {
            $params['pagination'] = '';
        }
        $this->adminView('services/servicesAll', $params);
    }

    public function servicesDisplay(Request $request, $servicesIdentify)
    {
        $servicesModel      = $this->model('servicesModel');
        $params['services'] = $servicesModel->displaySingle($servicesIdentify);
        $this->adminView('services/servicesSingle', $params);
    }

    public function servicesDestroy(Request $request, $servicesIdentify)
    {
        $servicesModel = $this->model('servicesModel');
        $servicesModel->erase($servicesIdentify);
        // success delete and redirect
        header("Location:  " . ROOT . "/admin/services/");
        $_SESSION['success_message'] = "Delete successful!";
        exit;
    }

    public function servicesbuild()
    {
        $this->adminView('services/servicesNew');
    }

    public function servicesRecord(Request $request)
    {
        $servicesModel           = $this->model('servicesModel');
        $data                    = $request->getBody();
        $data['serviceCreatedAt']  = date('Y-m-d H:i:s');
        $data['serviceUpdatedAt']  = date('Y-m-d H:i:s');
        $data['serviceIdentify'] = generateUniqueId(16);
        $rules                   = [
            'title'            => 'required|max:100',
            'category'         => 'required',
            'description'      => '',
            'icon'             => 'required|max:150',
            'status'           => 'required',
            'serviceCreatedAt' => '',
            'serviceUpdatedAt' => '',
            'serviceIdentify'  => 'required|max:50',
        ];
        $validator = new Validator();
        $validator->validate($rules);
        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $servicesModel->record($data);
            // success adding and redirect
            header("Location:  " . ROOT . "/admin/services/");
            $_SESSION['success_message'] = "Added successful!";
            exit;
        }
    }

    public function servicesModify(Request $request, $servicesIdentify)
    {
        $servicesModel             = $this->model('servicesModel');
        $params['serviceIdentify'] = $servicesIdentify;
        $params['services']        = $servicesModel->displaySingle($servicesIdentify);
        $this->adminView('services/servicesEdit', $params);
    }

    public function servicesEdit(Request $request, $servicesIdentify)
    {
        $servicesModel = $this->model('servicesModel');
        $data          = $request->getBody();
        $rules         = [
            'title'            => 'required|max:100',
            'category'         => 'required',
            'description'      => '',
            'icon'             => 'required|max:150',
            'status'           => 'required',
            'serviceCreatedAt' => '',
            'serviceUpdatedAt' => '',
            'serviceIdentify'  => 'required|max:50',
        ];
        $validator = new Validator();

        if ($validator->fails($rules)) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $servicesModel->modify($data, $servicesIdentify);
            // success updated and redirect
            header("Location:  " . ROOT . "/admin/services/");
            $_SESSION['success_message'] = "Update successful!";
            exit;
        }
    }
}
