<?php
class faqsController extends Controller
{
    public function faqsIndex()
    {
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        $faqsModel = $this->model('faqsModel');
        	$searchColumns = array (
  0 => 'faqId',
  1 => 'question',
  2 => 'answer',
  3 => 'faqCreatedAt',
  4 => 'faqUpdatedAt',
  5 => 'faqIdentify',
);
        $totalRecords = $faqsModel->countAll($search, $searchColumns);
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $pagination = new Paginator($totalRecords, $page, 10);
        $data = $faqsModel->displayAllSearch($search, $searchColumns, $pagination->getOffset(), $pagination->getLimit());
        $params['faqs'] = $data;
        if ($totalRecords > $pagination->getLimit()) {
            $params['pagination'] =  $pagination->render();
        } else {
            $params['pagination'] = '';
        }
        $this->adminView('faqs/faqsAll', $params);
    }

    public function faqsDisplay(Request $request, $faqsIdentify)
    {
        $faqsModel = $this->model('faqsModel');
        $params['faqs'] =  $faqsModel->displaySingle($faqsIdentify);
        $this->adminView('faqs/faqsSingle', $params);
    }

    public function faqsDestroy(Request $request, $faqsIdentify)
    {
        $faqsModel = $this->model('faqsModel');
        $faqsModel->erase($faqsIdentify);
            // success delete and redirect
header("Location:  " . ROOT . "/admin/faqs/");
            $_SESSION['success_message'] = "Delete successful!";
            exit;
    }

    public function faqsbuild()
    {
        $this->adminView('faqs/faqsNew');
    }

    public function faqsRecord(Request $request)
    {
        $faqsModel = $this->model('faqsModel');
        $data = $request->getBody();
        $data['faqCreatedAt'] = date('Y-m-d H:i:s');
        $data['faqUpdatedAt'] = date('Y-m-d H:i:s');
        $data['faqIdentify'] = generateUniqueId(16);
        	$rules = array (
  'question' => 'required|max:255',
  'answer' => '',
  'faqCreatedAt' => '',
  'faqUpdatedAt' => '',
  'faqIdentify' => 'required|max:50',
);
        $validator = new Validator();
        $validator->validate($rules);
        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $faqsModel->record($data);
            // success adding and redirect
header("Location:  " . ROOT . "/admin/faqs/");
            $_SESSION['success_message'] = "Added successful!";
            exit;
        }
    }

    public function faqsModify(Request $request,$faqsIdentify)
    {
        $faqsModel = $this->model('faqsModel');
        $params['faqIdentify'] = $faqsIdentify;
        $params['faqs'] =  $faqsModel->displaySingle($faqsIdentify);
        $this->adminView('faqs/faqsEdit', $params);
    }

    public function faqsEdit(Request $request, $faqsIdentify)
    {
        $faqsModel = $this->model('faqsModel');
        $data = $request->getBody();
        	$rules = array (
  'question' => 'required|max:255',
  'answer' => '',
  'faqCreatedAt' => '',
  'faqUpdatedAt' => '',
  'faqIdentify' => 'required|max:50',
);
        $validator = new Validator();

        if ($validator->fails($rules)) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $faqsModel->modify($data, $faqsIdentify);
            // success updated and redirect
header("Location:  " . ROOT . "/admin/faqs/");
            $_SESSION['success_message'] = "Update successful!";
            exit;
        }
    }
}
