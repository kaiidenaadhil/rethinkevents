<?php

class ContractController extends Controller {
    public function contractForm(Request $request, Response $response) {
        if ($request->method() === 'POST') {
            // Retrieve the CSRF token from the request
            $submittedToken = $request->getBody()['_csrf_token'] ?? null;

            try {
                // Validate CSRF token
                //CSRFMiddleware::validate($submittedToken);

                // Retrieve and process form data
                $formData = $request->getBody();
                $name = $formData['name'] ?? null;
                $email = $formData['email'] ?? null;
                $message = $formData['message'] ?? null;

                // Perform additional validation or save the data
                if (!$name || !$email || !$message) {
                    throw new Exception('All fields are required.');
                }

                // Example: Save the data to the database (pseudo-code)
                // Database::table('contracts')->insert(['name' => $name, 'email' => $email, 'message' => $message]);

                // Provide user feedback
                echo "Contract form submitted successfully!";
                return;
                exit;
            } catch (Exception $e) {
                // Handle validation errors
                http_response_code(403);
                echo 'Error: ' . $e->getMessage();
                return;
            }
        }

        // For GET requests, generate a CSRF token and load the form
       // $params['csrfToken'] = CSRFMiddleware::generate();
        return $this->view('contract');
    }
}
