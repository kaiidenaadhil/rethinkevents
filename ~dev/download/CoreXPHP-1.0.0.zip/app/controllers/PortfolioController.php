<?php
class portfolioController extends Controller
{
    public function portfolioIndex()
    {
        $search         = isset($_GET['search']) ? $_GET['search'] : '';
        $portfolioModel = $this->model('portfolioModel');
        $searchColumns  = [
            0 => 'portfolioId',
            1 => 'eventId',
            2 => 'galleryImage',
            3 => 'caption',
            4 => 'portfolioCreatedAt',
            5 => 'portfolioUpdatedAt',
            6 => 'portfolioIdentify',
        ];
        $totalRecords        = $portfolioModel->countAll($search, $searchColumns);
        $page                = isset($_GET['page']) ? (int) $_GET['page'] : 1;
        $pagination          = new Paginator($totalRecords, $page, 10);
        $data                = $portfolioModel->displayAllSearch($search, $searchColumns, $pagination->getOffset(), $pagination->getLimit());
        $params['portfolio'] = $data;
        if ($totalRecords > $pagination->getLimit()) {
            $params['pagination'] = $pagination->render();
        } else {
            $params['pagination'] = '';
        }
        $this->adminView('portfolio/portfolioAll', $params);
    }

    public function portfolioDisplay(Request $request, $portfolioIdentify)
    {
        $portfolioModel      = $this->model('portfolioModel');
        $params['portfolio'] = $portfolioModel->displaySingle($portfolioIdentify);
        $this->adminView('portfolio/portfolioSingle', $params);
    }

    public function portfolioDestroy(Request $request, $portfolioIdentify)
    {
        $portfolioModel = $this->model('portfolioModel');
        $portfolioModel->erase($portfolioIdentify);
        // success delete and redirect
        header("Location:  " . ROOT . "/admin/portfolio/");
        $_SESSION['success_message'] = "Delete successful!";
        exit;
    }

    public function portfoliobuild()
    {
        $this->adminView('portfolio/portfolioNew');
    }

    public function portfolioRecord(Request $request)
    {
        $portfolioModel            = $this->model('portfolioModel');
        $data                      = $request->getBody();
        $data['portfolioCreatedAt']  = date('Y-m-d H:i:s');
        $data['portfolioUpdatedAt']  = date('Y-m-d H:i:s');
        $data['portfolioIdentify'] = generateUniqueId(16);
        $rules                     = [
            'eventId'            => 'required',
            'galleryImage'       => 'required|max:255',
            'caption'            => 'required|max:150',
            'portfolioCreatedAt' => '',
            'portfolioUpdatedAt' => '',
            'portfolioIdentify'  => 'required|max:50',
        ];
        $validator = new Validator();
        $validator->validate($rules);
        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $portfolioModel->record($data);
            // success adding and redirect
            header("Location:  " . ROOT . "/admin/portfolio/");
            $_SESSION['success_message'] = "Added successful!";
            exit;
        }
    }

    public function portfolioModify(Request $request, $portfolioIdentify)
    {
        $portfolioModel              = $this->model('portfolioModel');
        $params['portfolioIdentify'] = $portfolioIdentify;
        $params['portfolio']         = $portfolioModel->displaySingle($portfolioIdentify);
        $this->adminView('portfolio/portfolioEdit', $params);
    }

    public function portfolioEdit(Request $request, $portfolioIdentify)
    {
        $portfolioModel = $this->model('portfolioModel');
        $data           = $request->getBody();
        $rules          = [
            'eventId'            => 'required',
            'galleryImage'       => 'required|max:255',
            'caption'            => 'required|max:150',
            'portfolioCreatedAt' => '',
            'portfolioUpdatedAt' => '',
            'portfolioIdentify'  => 'required|max:50',
        ];
        $validator = new Validator();

        if ($validator->fails($rules)) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $portfolioModel->modify($data, $portfolioIdentify);
            // success updated and redirect
            header("Location:  " . ROOT . "/admin/portfolio/");
            $_SESSION['success_message'] = "Update successful!";
            exit;
        }
    }
}
