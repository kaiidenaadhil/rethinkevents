<?php
class eventsController extends Controller
{
    public function eventsIndex()
    {
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        $eventsModel = $this->model('eventsModel');
        $searchColumns = array(
            0 => 'eventId',
            1 => 'title',
            2 => 'categoryId',
            3 => 'location',
            4 => 'eventDate',
            5 => 'eventTime',
            6 => 'coverImage',
            7 => 'summary',
            8 => 'status',
            9 => 'eventCreatedAt',
            10 => 'eventUpdatedAt',
            11 => 'eventIdentify',
        );
        $totalRecords = $eventsModel->countAll($search, $searchColumns);
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $pagination = new Paginator($totalRecords, $page, 10);
        $data = $eventsModel->displayAllSearch($search, $searchColumns, $pagination->getOffset(), $pagination->getLimit());
        $params['events'] = $data;
        if ($totalRecords > $pagination->getLimit()) {
            $params['pagination'] =  $pagination->render();
        } else {
            $params['pagination'] = '';
        }
        $this->adminView('events/eventsAll', $params);
    }

    public function eventsDisplay(Request $request, $eventsIdentify)
    {
        $eventsModel = $this->model('eventsModel');
        $params['events'] =  $eventsModel->displaySingle($eventsIdentify);
        $this->adminView('events/eventsSingle', $params);
    }

    public function eventsDestroy(Request $request, $eventsIdentify)
    {
        $eventsModel = $this->model('eventsModel');
        $eventsModel->erase($eventsIdentify);
        // success delete and redirect
        header("Location:  " . ROOT . "/admin/events/");
        $_SESSION['success_message'] = "Delete successful!";
        exit;
    }

    public function eventsbuild()
    {
        $this->adminView('events/eventsNew');
    }

    public function eventsRecord(Request $request)
    {
        $eventsModel = $this->model('eventsModel');
        $data = $request->getBody();
        $data['eventCreatedAt'] = date('Y-m-d H:i:s');
        $data['eventUpdatedAt'] = date('Y-m-d H:i:s');
        $data['eventIdentify'] = generateUniqueId(16);
        $rules = array(
            'title' => 'required|max:150',
            'categoryId' => 'required',
            'location' => 'required|max:200',
            'eventDate' => 'required|max:50',
            'eventTime' => 'required|max:50',
            'coverImage' => 'required|max:255',
            'summary' => '',
            'status' => 'required',
            'eventCreatedAt' => '',
            'eventUpdatedAt' => '',
            'eventIdentify' => 'required|max:50',
        );
        $validator = new Validator();
        $validator->validate($rules);
        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $eventsModel->record($data);
            // success adding and redirect
            header("Location:  " . ROOT . "/admin/events/");
            $_SESSION['success_message'] = "Added successful!";
            exit;
        }
    }

    public function eventsModify(Request $request, $eventsIdentify)
    {
        $eventsModel = $this->model('eventsModel');
        $params['eventIdentify'] = $eventsIdentify;
        $params['events'] =  $eventsModel->displaySingle($eventsIdentify);
        $this->adminView('events/eventsEdit', $params);
    }

    public function eventsEdit(Request $request, $eventsIdentify)
    {
        $eventsModel = $this->model('eventsModel');
        $data = $request->getBody();
        $rules = array(
            'title' => 'required|max:150',
            'categoryId' => 'required',
            'location' => 'required|max:200',
            'eventDate' => 'required|max:50',
            'eventTime' => 'required|max:50',
            'coverImage' => 'required|max:255',
            'summary' => '',
            'status' => 'required',
            'eventCreatedAt' => '',
            'eventUpdatedAt' => '',
            'eventIdentify' => 'required|max:50',
        );
        $validator = new Validator();

        if ($validator->fails($rules)) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $eventsModel->modify($data, $eventsIdentify);
            // success updated and redirect
            header("Location:  " . ROOT . "/admin/events/");
            $_SESSION['success_message'] = "Update successful!";
            exit;
        }
    }
}
