<?php

class ContactController extends Controller {

    public function index(){
        return $this->view('contact');
    }

    public function contact(Request $request, Response $response) {
        // Step 1: Get form data
        $data = $request->getBody();

        // Step 2: Validate data
        $errors = [];
        if (empty($data['clientName'])) {
            $errors['clientName'] = 'Name is required.';
        }
        if (empty($data['clientEmail']) || !filter_var($data['clientEmail'], FILTER_VALIDATE_EMAIL)) {
            $errors['clientEmail'] = 'A valid email is required.';
        }
        if (empty($data['clientMessage'])) {
            $errors['clientMessage'] = 'Message is required.';
        }

        // Step 3: Return errors if validation fails
        if (!empty($errors)) {
            return $response->json([
                'status' => 'error',
                'message' => 'Validation errors occurred.',
                'errors' => $errors,
            ]);
        }

        // Step 4: Process the data (e.g., save to DB or send email)
        $recaptchaSecret = '6LeX55YqAAAAANocx1g8gsNx7i-qkG5EHWukfBng'; // Your secret key
        $recaptchaResponse = $_POST['g-recaptcha-response'] ?? '';
        
        // if (empty($recaptchaResponse)) {
        //     die(json_encode([
        //         'status' => 'error',
        //         'message' => 'reCAPTCHA verification failed. Please try again.',
        //     ]));
        // }
        
        // // Verify reCAPTCHA response
        // $url = "https://www.google.com/recaptcha/api/siteverify";
        // $params = [
        //     'secret' => $recaptchaSecret,
        //     'response' => $recaptchaResponse,
        // ];
        
        // $ch = curl_init($url);
        // curl_setopt($ch, CURLOPT_POST, true);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // $verifyResponse = curl_exec($ch);
        // curl_close($ch);
        
        // $responseData = json_decode($verifyResponse);
        
        // if (!$responseData->success || $responseData->score < 0.5) {
        //     // Low score or failure
        //     die(json_encode([
        //         'status' => 'error',
        //         'message' => 'reCAPTCHA verification failed. Are you a robot?',
        //     ]));
        // }

        
                // Step 4: Send email using PHPMailer
                $mailService = App::$service->get('mail');
                $mailSent = $mailService->send([
                    'to' => 'kaiidenaadhil@gmail.com', // Your destination email
                    'subject' => 'New Contact Form Submission',
                    'template' => 'contact', // Refers to /app/views/<theme>/@email/contact.php
                    'templateParams' => [
                        'name' => $data['clientName'],
                        'email' => $data['clientEmail'],
                        'whatsapp' => $data['whatsapp'],
                        'message' => $data['clientMessage'],
                    ],
                ]);
                if (!$mailSent) {
                    return $response->json([
                        'status' => 'error',
                        'message' => 'Failed to send email. Please try again later.',
                    ]);
                }
        // This is where you can add further logic, like:
        // - Saving to a database
        // - Sending an email using PHPMailer
        // For now, we will simulate a success message.

        // Step 5: Return a success response
        return $response->json([
            'status' => 'success',
            'message' => 'Your message has been received successfully!',
            'data' => $data, // Optional: Echo back the data for debugging
        ]);
    }
}