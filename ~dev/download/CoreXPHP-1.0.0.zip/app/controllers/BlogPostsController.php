<?php
class blogPostsController extends Controller
{
    public function blogPostsIndex()
    {
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        $blogPostsModel = $this->model('blogPostsModel');
        	$searchColumns = array (
  0 => 'postId',
  1 => 'title',
  2 => 'slug',
  3 => 'content',
  4 => 'coverImage',
  5 => 'status',
  6 => 'blogPostCreatedAt',
  7 => 'blogPostUpdatedAt',
  8 => 'blogPostIdentify',
);
        $totalRecords = $blogPostsModel->countAll($search, $searchColumns);
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $pagination = new Paginator($totalRecords, $page, 10);
        $data = $blogPostsModel->displayAllSearch($search, $searchColumns, $pagination->getOffset(), $pagination->getLimit());
        $params['blogPosts'] = $data;
        if ($totalRecords > $pagination->getLimit()) {
            $params['pagination'] =  $pagination->render();
        } else {
            $params['pagination'] = '';
        }
        $this->adminView('blogPosts/blogPostsAll', $params);
    }

    public function blogPostsDisplay(Request $request, $blogPostsIdentify)
    {
        $blogPostsModel = $this->model('blogPostsModel');
        $params['blogPosts'] =  $blogPostsModel->displaySingle($blogPostsIdentify);
        $this->adminView('blogPosts/blogPostsSingle', $params);
    }

    public function blogPostsDestroy(Request $request, $blogPostsIdentify)
    {
        $blogPostsModel = $this->model('blogPostsModel');
        $blogPostsModel->erase($blogPostsIdentify);
            // success delete and redirect
header("Location:  " . ROOT . "/admin/blogPosts/");
            $_SESSION['success_message'] = "Delete successful!";
            exit;
    }

    public function blogPostsbuild()
    {
        $this->adminView('blogPosts/blogPostsNew');
    }

    public function blogPostsRecord(Request $request)
    {
        $blogPostsModel = $this->model('blogPostsModel');
        $data = $request->getBody();
        $data['blogPostUpdatedAt'] = date('Y-m-d H:i:s');
        $data['blogPostCreatedAt'] = date('Y-m-d H:i:s');
        $data['blogPostIdentify'] = generateUniqueId(16);
        	$rules = array (
  'title' => 'required|max:200',
  'slug' => 'required|max:200',
  'content' => '',
  'coverImage' => 'required|max:255',
  'status' => 'required',
  'blogPostCreatedAt' => '',
  'blogPostUpdatedAt' => '',
  'blogPostIdentify' => 'required|max:50',
);
        $validator = new Validator();
        $validator->validate($rules);
        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $blogPostsModel->record($data);
            // success adding and redirect
header("Location:  " . ROOT . "/admin/blogPosts/");
            $_SESSION['success_message'] = "Added successful!";
            exit;
        }
    }

    public function blogPostsModify(Request $request,$blogPostsIdentify)
    {
        $blogPostsModel = $this->model('blogPostsModel');
        $params['blogPostIdentify'] = $blogPostsIdentify;
        $params['blogPosts'] =  $blogPostsModel->displaySingle($blogPostsIdentify);
        $this->adminView('blogPosts/blogPostsEdit', $params);
    }

    public function blogPostsEdit(Request $request, $blogPostsIdentify)
    {
        $blogPostsModel = $this->model('blogPostsModel');
        $data = $request->getBody();
        	$rules = array (
  'title' => 'required|max:200',
  'slug' => 'required|max:200',
  'content' => '',
  'coverImage' => 'required|max:255',
  'status' => 'required',
  'blogPostCreatedAt' => '',
  'blogPostUpdatedAt' => '',
  'blogPostIdentify' => 'required|max:50',
);
        $validator = new Validator();

        if ($validator->fails($rules)) {
            $errors = $validator->errors();
            foreach ($errors as $error) {
                echo $error . "</br>";
            }
        } else {
            $blogPostsModel->modify($data, $blogPostsIdentify);
            // success updated and redirect
header("Location:  " . ROOT . "/admin/blogPosts/");
            $_SESSION['success_message'] = "Update successful!";
            exit;
        }
    }
}
